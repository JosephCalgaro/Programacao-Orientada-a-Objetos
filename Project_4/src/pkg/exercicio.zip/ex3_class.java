package pkg;

public class ex3_class {

}
